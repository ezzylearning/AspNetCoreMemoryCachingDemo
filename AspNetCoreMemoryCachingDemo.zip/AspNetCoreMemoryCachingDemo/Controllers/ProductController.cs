﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspNetCoreMemoryCachingDemo.Data;
using AspNetCoreMemoryCachingDemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace AspNetCoreMemoryCachingDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly AdventureWorksDbContext _context;
        private readonly IMemoryCache _cache;

        public ProductController(AdventureWorksDbContext context, IMemoryCache cache)
        {
            _context = context;
            _cache = cache;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var cacheKey = "GET_ALL_PRODUCTS";

            // If data found in cache, return cached data
            if (_cache.TryGetValue(cacheKey, out List<Product> products))
            {
                return Ok(products); 
            }

            // If not found, then fetch data from database
            products = await _context.Products.ToListAsync();

            //// Set cache options
            //var cacheOptions = new MemoryCacheEntryOptions()
            //{
            //    AbsoluteExpiration = DateTime.Now.AddMinutes(5)
            //};

            //// Set cache options
            //var cacheOptions = new MemoryCacheEntryOptions()
            //{
            //    SlidingExpiration = TimeSpan.FromMinutes(5)
            //};

            // Set cache options
            //var cacheOptions = new MemoryCacheEntryOptions()
            //{
            //    SlidingExpiration = TimeSpan.FromMinutes(5),
            //    AbsoluteExpiration = DateTime.Now.AddMinutes(60)
            //};

            var cacheOptions = new MemoryCacheEntryOptions()
            {
                AbsoluteExpiration = DateTime.Now.AddMinutes(60),
                Priority = CacheItemPriority.High
            };

            cacheOptions.RegisterPostEvictionCallback(
                (key, value, reason, substate) =>
                {
                    Console.Write("Cache expired!");
                });










            // Add data in cache
            _cache.Set(cacheKey, products, cacheOptions);

            return Ok(products);
        }
    }
}
